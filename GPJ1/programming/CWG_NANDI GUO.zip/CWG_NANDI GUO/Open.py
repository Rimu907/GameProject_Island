"""
Created on Fri Dec 4 22:09:30 2020

@author: CHAO CUI, HAO WU, NANDI GUO
"""
# Start the game
import Start_Screen
Start_Screen.Firstscreen()

